/*
 * led_controller.h
 *
 *  Created on: Aug 13, 2025
 *      Author: duong
 */

#ifndef LED_CONTROLL_LED_CONTROLLER_H_
#define LED_CONTROLL_LED_CONTROLLER_H_
#include "main.h"
void led_controller_init(GPIO_TypeDef* gpio_x);
void led_process(void);



#endif /* LED_CONTROLL_LED_CONTROLLER_H_ */
