/*
 * mavlink_from_FC.c
 *
 *  Created on: Aug 13, 2025
 *      Author: duong
 */
#include "mavlink_from_FC.h"
#include "mavlink.h"
#include "uart.h"
#define MAV_PARSE_MAX_BYTES   128
#define MAV_PARSE_MAX_MSGS    2
#define MAV_PARSE_BUDGET_MS   1000
extern UART_HandleTypeDef huart3;
uint8_t data_rx;
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
	if(huart->Instance == USART3)
	{
		receive_rx(data_rx);
		HAL_UART_Receive_IT(huart, &data_rx, 1);
	}
}
void mavlink_process(mavlink_from_fc_t* mav_fc, uint32_t now)
{
	if(uart_available() > 0)
	{
		uint8_t read_data = uart_read();
		if (mavlink_parse_char(MAVLINK_COMM_0, read_data, &mav_fc->rx_msg, &mav_fc->status))
		{
			switch(mav_fc->rx_msg.msgid)
			{
				case MAVLINK_MSG_ID_HEARTBEAT:
				{
					mavlink_msg_heartbeat_decode(&mav_fc->rx_msg, &mav_fc->hb);
					break;
				}
				case MAVLINK_MSG_ID_ATTITUDE:
				{
					mavlink_msg_attitude_decode(&mav_fc->rx_msg, &mav_fc->att);
					mav_fc->att_last_ms = now;
					break;
				}
			}
		}
	}
}
void mavlink_init(void)
{
	uart_init();
	HAL_UART_Receive_IT(&huart3, &data_rx, 1);
}
